================================================================================
                        MathPix Processing Archive
================================================================================

Generated: 31 May 2026 at 18:59 GMT
Archive Version: 1.0
Archive Type: Complete Processing Archive

================================================================================
INTERACTION SUMMARY
================================================================================

API Type:          PDF
Source:            File Upload
Processing Date:   31 May 2026 at 18:59 GMT
Confidence Score:  87.5% (High)

Content Type:      math
Processing Mode:   PDF Document

================================================================================
PROCESSING SUMMARY
================================================================================

Processing Date:     31 May 2026 at 18:59 GMT
Processing Duration: 15.84s
Processing Mode:     PDF Document
Source File:         08-capacitors.pdf (7.8 MB)
Pages Processed:     All pages (6 of 6)

Quality Metrics:
- Confidence Score:    87.5% (High)
- Confidence Rate:     87.5%
- Processing Model:    Default
- Content Type:        math
- Processing Status:   Completed Successfully

================================================================================
ARCHIVE CONTENTS
================================================================================

This archive contains all resources from your MathPix processing session,
organised for accessibility remediation and quality assurance purposes.

/source/
  Original input materials:
    - 08-capacitors.pdf (7997.9 KB)

/results/
  Conversion outputs in multiple formats:
    - 08-capacitors.mmd (6.4 KB)

/data/
  Processing metadata and debug information:
  - api-request.json:    Sanitized API request (credentials removed)
  - api-response.json:   Complete API response data
  - debug-info.md:       Debug information in Markdown format
  - metadata.json:       Structured processing metadata

  
  




README.txt
  This file - Archive documentation

================================================================================
ARCHIVE STATISTICS
================================================================================

Total Archive Size:  7.8 MB
- Source Files:    7.8 MB (1 file)
- Result Files:    6.4 KB (1 file)

Result Files by Size:
  - 08-capacitors.mmd                        6.4 KB (MathPix Markdown)

Source Files:
  - 08-capacitors.pdf                        7.8 MB

================================================================================
PROCESSING DETAILS
================================================================================

Content Analysis:
  - Content Type:    math
  - Total Lines:     28
  - Math Elements:   0
  - Handwritten:     24 lines
  - Printed:         4 lines
  - Tables Detected: 0

Processing Quality:
- Confidence:        87.5% (High)
- Confidence Rate:   87.5%
- Processing Model:  Default
- Type:              PDF Document

================================================================================
FORMATS INCLUDED
================================================================================

MathPix Markdown (.mmd)
    MathPix's enhanced Markdown format with mathematics
    
Markdown (.md)
    Standard Markdown format
    
HTML (.html)
    Web-compatible HTML document
    
Microsoft Word (.docx)
    Editable Word document format (binary)
    
LaTeX Archive (.zip)
    Complete LaTeX project in nested ZIP (not extracted)

================================================================================
TECHNICAL INFORMATION
================================================================================

Request ID:        5a612f1a-aeef-45cd-9a95-55d6f23122e2
API Version:       v3
Processing Region: European Union (Frankfurt) - Privacy-first processing
Total Files:       2 (1 source + 1 results)

For detailed processing information, see:
- /data/api-response.json for complete API response
- /data/debug-info.md for debug information
- /data/metadata.json for structured metadata

================================================================================
ACCESSIBILITY NOTES
================================================================================

This archive is designed for document remediation workflows:

1. Source materials are preserved for reference
2. Multiple format options for maximum compatibility
3. Complete metadata for quality assurance
4. Structured folder organisation for easy navigation

For accessibility remediation:
- Use HTML or DOCX formats for screen reader testing
- LaTeX provides semantic structure for mathematical content
- Metadata includes confidence scores to identify areas needing review
- Multiple formats ensure compatibility with various tools

================================================================================
SUPPORT
================================================================================

For questions about this archive or MathPix processing:
- Review /data/api-response.json for detailed processing information
- Check /data/debug-info.md for technical details
- Consult /data/metadata.json for structured data

Archive Format Version: 1.0
Generated by: MathPix Total Downloader
Timestamp: 2026-05-31T18:59:06.478Z
================================================================================